/// ARCA — Adaptive Resonant Cortical Architecture
///
/// Entry point: wires all modules into a complete forward + slow-learning pass.
///
/// GPU integration:
///   Build with:  cargo build --release --features gpu
///   CPU-only:    cargo build --release
///
/// Changes vs original CPU-only main.rs:
///   [GPU] ArcaSystem gains gpu / s_t_shadow / m_shadows fields (feature-gated)
///   [GPU] forward_step dispatches R·s, Hebbian updates, and logits to the GPU
///   [GPU] reset_state zeros GPU-resident VRAM buffers
///   [GPU] save_weights reads back M matrices from VRAM before serialising
///   [GPU] After slow-learning SGD updates W_in / embeddings, they are re-uploaded

mod encoder;
mod memory;
mod metabolic_core;
mod sovereign;
mod tokenizer;
mod train;

#[cfg(feature = "gpu")]
mod gpu_context;

use ndarray::{Array1, Array2};

use encoder::{MultiScaleEncoder, BPE_VOCAB_SIZE, D_BPE, D_MODEL, D_PHRASE, PHRASE_WIN_MIN};
use memory::{HolographicMemoryAggregator, PredictionHead, SparseOutputHead, VOCAB_SIZE};
use metabolic_core::{
    BioInspiredLayer, GlobalMetabolicController, LiquidReservoir, LshRouter, N_RES, RANK_R,
};
use sovereign::{SovereignError, SovereignHeader, SovereignModel};
use tokenizer::BpeTokenizer;
use train::{TrainConfig, TrainState, build_batches};

// ─────────────────────────────────────────────────────────────────────────────
// ARCA system
// ─────────────────────────────────────────────────────────────────────────────

pub struct ArcaSystem {
    encoder:          MultiScaleEncoder,
    reservoir:        LiquidReservoir,
    lsh:              LshRouter,
    controller:       GlobalMetabolicController,
    layers:           Vec<BioInspiredLayer>,
    prediction_head:  PredictionHead,
    train_state:      TrainState,
    // CPU-path state (also used as a CPU shadow in the GPU path)
    reservoir_state:  Array1<f32>,
    memory_states:    Vec<Array2<f32>>,
    tension:          f32,

    // ── GPU fields (compiled only when `--features gpu`) ──────────────────
    #[cfg(feature = "gpu")]
    gpu:              gpu_context::GpuContext,

    /// CPU shadow of the GPU-resident reservoir state s_t.
    /// Updated once per step via a 16 KiB readback after `dispatch_reservoir`.
    #[cfg(feature = "gpu")]
    s_t_shadow:       Array1<f32>,

    /// CPU shadows of the GPU-resident M matrices.
    /// Each shadow is RANK_R × RANK_R (4 KiB); updated once per step per layer.
    #[cfg(feature = "gpu")]
    m_shadows:        Vec<Array2<f32>>,
}

// ─────────────────────────────────────────────────────────────────────────────
// Random-init helpers
// ─────────────────────────────────────────────────────────────────────────────

fn make_rand_2d(r: usize, c: usize) -> Array2<f32> {
    use rand::Rng;
    let mut rng   = rand::thread_rng();
    let scale      = (2.0 / (r + c) as f32).sqrt();
    Array2::from_shape_fn((r, c), |_| rng.gen_range(-scale..scale))
}

fn make_rand_1d(n: usize) -> Array1<f32> {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    Array1::from_shape_fn(n, |_| rng.gen_range(-0.1_f32..0.1_f32))
}

// ─────────────────────────────────────────────────────────────────────────────
// ArcaSystem construction
// ─────────────────────────────────────────────────────────────────────────────

impl ArcaSystem {
    /// Build from a loaded `.sovereign` weight file.
    pub fn from_sovereign(model: &SovereignModel) -> Result<Self, SovereignError> {
        let h     = &model.header;
        let num_l = h.num_layers;

        // Encoder
        let bpe_emb  = model.tensor_as_array2("bpe_embeddings")?;
        let w_fusion = model.tensor_as_array2("w_fusion")?;
        let w_phrase = model.tensor_as_array2("w_phrase")?;
        let encoder  = MultiScaleEncoder::new(bpe_emb, w_fusion, w_phrase);

        // Reservoir
        let r_matrix = model.generate_sparse_lsm();
        let w_in     = model.tensor_as_array2("w_in")?;
        let reservoir = LiquidReservoir::new(r_matrix, w_in);

        // LSH
        let w_lsh = model.tensor_as_array2("w_lsh")?;
        let lsh   = LshRouter::new(w_lsh);

        let controller = GlobalMetabolicController::new(num_l, 0.01, 1.0, 0.8, 0.999);

        // Layers
        let mut layers = Vec::with_capacity(num_l);
        for l in 0..num_l {
            let w_down  = model.tensor_as_array2(&format!("w_down_{}", l))?;
            let w_up    = model.tensor_as_array2(&format!("w_up_{}", l))?;
            let m_base  = model.tensor_as_array2(&format!("m_base_{}", l))?;
            let gamma1d = model.tensor_as_array1(&format!("gamma_{}", l))?;
            layers.push(BioInspiredLayer::new(w_down, w_up, m_base, gamma1d[0]));
        }

        // Output head
        let w_out      = model.tensor_as_array2("w_out")?;
        let aggregator = HolographicMemoryAggregator::new(w_out);
        let out_emb    = model.tensor_as_array2("output_embeddings")?;
        let out_bias   = model.tensor_as_array1("output_bias")?;
        let head       = SparseOutputHead::new(out_emb, out_bias);
        let prediction_head = PredictionHead::new(aggregator, head);

        let train_state   = TrainState::new(TrainConfig::default());
        let memory_states = (0..num_l)
            .map(|_| Array2::zeros((RANK_R, RANK_R)))
            .collect::<Vec<_>>();

        // ── GPU context ───────────────────────────────────────────────────
        #[cfg(feature = "gpu")]
        let gpu = {
            use gpu_context::GpuContext;

            let r_flat: Vec<f32> = reservoir.r_matrix.iter().cloned().collect();
            let w_in_flat: Vec<f32> = reservoir.w_in.iter().cloned().collect();
            let out_emb_flat: Vec<f32> =
                prediction_head.head.output_embeddings.iter().cloned().collect();
            let out_bias_flat: Vec<f32> =
                prediction_head.head.output_bias.iter().cloned().collect();
            let m_base_data: Vec<Vec<f32>> = layers
                .iter()
                .map(|l| l.m_base.iter().cloned().collect())
                .collect();

            GpuContext::new(
                num_l,
                &r_flat,
                &w_in_flat,
                &out_emb_flat,
                &out_bias_flat,
                &m_base_data,
            )
        };

        Ok(ArcaSystem {
            encoder,
            reservoir,
            lsh,
            controller,
            layers,
            prediction_head,
            train_state,
            reservoir_state: Array1::zeros(N_RES),
            memory_states,
            tension: 0.0,

            #[cfg(feature = "gpu")]
            gpu,
            #[cfg(feature = "gpu")]
            s_t_shadow: Array1::zeros(N_RES),
            #[cfg(feature = "gpu")]
            m_shadows: (0..num_l)
                .map(|_| Array2::zeros((RANK_R, RANK_R)))
                .collect(),
        })
    }

    /// Build with random weights (for demos / init).
    pub fn new_random(header: &SovereignHeader) -> Self {
        use rand::Rng;
        let num_l         = header.num_layers;
        let phrase_in_dim = PHRASE_WIN_MIN * D_BPE;

        let encoder = MultiScaleEncoder::new(
            make_rand_2d(BPE_VOCAB_SIZE, D_BPE),
            make_rand_2d(D_MODEL, D_MODEL),
            make_rand_2d(D_PHRASE, phrase_in_dim),
        );

        let r_matrix  = SovereignModel::new_random_lsm(header);
        let reservoir = LiquidReservoir::new(r_matrix, make_rand_2d(N_RES, D_MODEL));
        let lsh       = LshRouter::new(make_rand_2d(header.lsh_k, N_RES));
        let controller = GlobalMetabolicController::new(num_l, 0.01, 1.0, 0.8, 0.999);

        let layers: Vec<BioInspiredLayer> = (0..num_l)
            .map(|_| {
                let g: f32 = rand::thread_rng().gen_range(-0.05..0.05);
                BioInspiredLayer::new(
                    make_rand_2d(RANK_R, D_MODEL),
                    make_rand_2d(RANK_R, N_RES),
                    Array2::zeros((RANK_R, RANK_R)),
                    g,
                )
            })
            .collect();

        let aggregator  = HolographicMemoryAggregator::new(make_rand_2d(D_MODEL, N_RES));
        let head        = SparseOutputHead::new(
            make_rand_2d(VOCAB_SIZE, D_MODEL),
            make_rand_1d(VOCAB_SIZE),
        );
        let prediction_head = PredictionHead::new(aggregator, head);
        let train_state     = TrainState::new(TrainConfig::default());
        let memory_states   = (0..num_l)
            .map(|_| Array2::zeros((RANK_R, RANK_R)))
            .collect::<Vec<_>>();

        // ── GPU context (random init) ─────────────────────────────────────
        #[cfg(feature = "gpu")]
        let gpu = {
            use gpu_context::GpuContext;

            let r_flat: Vec<f32> = reservoir.r_matrix.iter().cloned().collect();
            let w_in_flat: Vec<f32> = reservoir.w_in.iter().cloned().collect();
            let out_emb_flat: Vec<f32> =
                prediction_head.head.output_embeddings.iter().cloned().collect();
            let out_bias_flat: Vec<f32> =
                prediction_head.head.output_bias.iter().cloned().collect();
            let m_base_data: Vec<Vec<f32>> = layers
                .iter()
                .map(|l| l.m_base.iter().cloned().collect())
                .collect();

            GpuContext::new(
                num_l,
                &r_flat,
                &w_in_flat,
                &out_emb_flat,
                &out_bias_flat,
                &m_base_data,
            )
        };

        ArcaSystem {
            encoder,
            reservoir,
            lsh,
            controller,
            layers,
            prediction_head,
            train_state,
            reservoir_state: Array1::zeros(N_RES),
            memory_states,
            tension: 0.0,

            #[cfg(feature = "gpu")]
            gpu,
            #[cfg(feature = "gpu")]
            s_t_shadow: Array1::zeros(N_RES),
            #[cfg(feature = "gpu")]
            m_shadows: (0..num_l)
                .map(|_| Array2::zeros((RANK_R, RANK_R)))
                .collect(),
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // forward_step — GPU path
    // ─────────────────────────────────────────────────────────────────────────

    /// GPU-accelerated forward pass.
    ///
    /// Hot-loop PCIe traffic:
    ///   - Upload:   x_t (2 KiB) + 2 × RANK_R scalars per layer (128 B each)
    ///               + y_hidden (2 KiB)
    ///   - Download: s_t (16 KiB) + RANK_R² per layer (4 KiB) + logits (195 KiB)
    ///
    /// No full matrix transfer (R, W_in, embeddings) in the hot loop.
    #[cfg(feature = "gpu")]
    pub fn forward_step(
        &mut self,
        raw_bytes:       &[u8],
        t:               usize,
        bpe_ids:         &[u32],
        prev_prediction: Option<&Array1<f32>>,
    ) -> ForwardOutput {
        use memory::VOCAB_SIZE;

        let x_t = self.encoder.encode_position(raw_bytes, t, bpe_ids);

        // Prediction error — tiny, CPU
        let e_t: Array1<f32> = match prev_prediction {
            Some(pred) => &x_t - pred,
            None       => Array1::zeros(D_MODEL),
        };

        // Homeostatic climate — scalar arithmetic, CPU
        let (tension_new, beta_g, lambda_g, sigma_g) =
            self.controller.compute_climate(&e_t, self.tension);
        self.tension = tension_new;

        // ── Reservoir step (GPU) ──────────────────────────────────────────
        self.reservoir.step_gpu(&mut self.gpu, &x_t);

        // Read back s_t shadow once (16 KiB ≈ 1 µs over PCIe)
        let s_cpu_vec = self.gpu.readback_s();
        self.s_t_shadow = Array1::from_vec(s_cpu_vec);

        // LSH hash on the CPU shadow
        let _h_st = self.lsh.hash(&self.s_t_shadow);

        // ── Per-layer Hebbian updates (GPU) ───────────────────────────────
        let eta    = self.train_state.config.eta_lr_hebbian;
        let num_l  = self.layers.len();
        let mut kappas = Vec::with_capacity(num_l);

        for (l, layer) in self.layers.iter().enumerate() {
            let depth_scale = 1.0 / (1.0 + l as f32 * 0.1);
            let e_local: Array1<f32> = &e_t * depth_scale;

            let kappa = layer.forward_gpu(
                &mut self.gpu,
                l,
                &e_local,
                &self.s_t_shadow,
                beta_g,
                lambda_g,
                sigma_g,
                eta,
                0.05,
                1024.0,
            );
            kappas.push(kappa);
        }

        // Read back per-layer M shadows (4 KiB each; L=4 → 16 KiB total)
        for l in 0..num_l {
            let m_flat = self.gpu.readback_m_layer(l);
            self.m_shadows[l] = Array2::from_shape_vec((RANK_R, RANK_R), m_flat)
                .expect("m_shadow reshape failed");
        }

        // Layer read-outs on CPU shadows (RANK_R × RANK_R matrix × RANK_R vec)
        let layer_readouts: Vec<Array1<f32>> = self.layers
            .iter()
            .enumerate()
            .map(|(l, layer)| layer.read_out_cpu(&self.m_shadows[l], &self.s_t_shadow))
            .collect();

        // ── Logit computation (GPU) ───────────────────────────────────────
        let (full_logits, sparse_logits) = self
            .prediction_head
            .forward_gpu(&mut self.gpu, &self.s_t_shadow, &layer_readouts);

        let x_hat_next = self.prediction_head.predict_embedding(&self.s_t_shadow);

        ForwardOutput {
            logits:           full_logits,
            sparse_logits,
            prediction_error: e_t,
            next_prediction:  x_hat_next,
            kappas,
            tension:          self.tension,
            beta_global:      beta_g,
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // forward_step — CPU-only path (compiled when `gpu` feature is absent)
    // ─────────────────────────────────────────────────────────────────────────

    #[cfg(not(feature = "gpu"))]
    pub fn forward_step(
        &mut self,
        raw_bytes:       &[u8],
        t:               usize,
        bpe_ids:         &[u32],
        prev_prediction: Option<&Array1<f32>>,
    ) -> ForwardOutput {
        let x_t = self.encoder.encode_position(raw_bytes, t, bpe_ids);

        let e_t: Array1<f32> = match prev_prediction {
            Some(pred) => &x_t - pred,
            None       => Array1::zeros(D_MODEL),
        };

        let (tension_new, beta_g, lambda_g, sigma_g) =
            self.controller.compute_climate(&e_t, self.tension);
        self.tension = tension_new;

        let s_t   = self.reservoir.step(&self.reservoir_state, &x_t);
        let _h_st = self.lsh.hash(&s_t);

        let mut kappas       = Vec::with_capacity(self.layers.len());
        let mut layer_readouts = Vec::with_capacity(self.layers.len());
        let eta = self.train_state.config.eta_lr_hebbian;

        for (l, layer) in self.layers.iter().enumerate() {
            let depth_scale = 1.0 / (1.0 + l as f32 * 0.1);
            let e_local: Array1<f32> = &e_t * depth_scale;

            let (m_new, kappa_l) = layer.forward_and_adapt(
                &self.memory_states[l],
                &e_local,
                &s_t,
                beta_g,
                lambda_g,
                sigma_g,
                eta,
                0.05,
                1024.0,
            );

            let readout = layer.read_out(&m_new, &s_t);
            layer_readouts.push(readout);
            kappas.push(kappa_l);
            self.memory_states[l] = m_new;
        }

        self.reservoir_state = s_t.clone();

        let (full_logits, sparse_logits) =
            self.prediction_head.forward(&s_t, &layer_readouts);

        let x_hat_next = self.prediction_head.predict_embedding(&s_t);

        ForwardOutput {
            logits:           full_logits,
            sparse_logits,
            prediction_error: e_t,
            next_prediction:  x_hat_next,
            kappas,
            tension:          self.tension,
            beta_global:      beta_g,
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // backward_step (CPU, unchanged)
    // ─────────────────────────────────────────────────────────────────────────

    pub fn backward_step(
        &mut self,
        output:       &ForwardOutput,
        target_token: usize,
    ) -> train::LossComponents {
        // Use the CPU reservoir state.
        // GPU path: reservoir_state is not updated each step; use s_t_shadow.
        #[cfg(feature = "gpu")]
        let s_for_loss = &self.s_t_shadow;
        #[cfg(not(feature = "gpu"))]
        let s_for_loss = &self.reservoir_state;

        let layer_refs: Vec<&BioInspiredLayer> = self.layers.iter().collect();
        let losses = self.train_state.compute_losses(
            &output.logits,
            target_token,
            &layer_refs,
            &output.prediction_error,
            s_for_loss,
            &output.kappas,
        );

        let mut new_gammas: Vec<f32> = self.layers.iter().map(|l| l.gamma).collect();
        for (l, gamma) in new_gammas.iter_mut().enumerate() {
            self.train_state.update_gamma(gamma, output.kappas[l]);
        }
        for (l, layer) in self.layers.iter_mut().enumerate() {
            layer.gamma = new_gammas[l];
        }

        losses
    }

    // ─────────────────────────────────────────────────────────────────────────
    // reset_state
    // ─────────────────────────────────────────────────────────────────────────

    pub fn reset_state(&mut self) {
        self.reservoir_state.fill(0.0);
        for m in self.memory_states.iter_mut() {
            m.fill(0.0);
        }
        self.tension = 0.0;

        #[cfg(feature = "gpu")]
        {
            self.gpu.reset_reservoir_state();
            self.gpu.reset_m_states(self.layers.len());
            self.s_t_shadow.fill(0.0);
            for m in self.m_shadows.iter_mut() {
                m.fill(0.0);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // save_weights
    //
    // In the GPU path we must read back the GPU-resident M matrices before
    // serialising.  W_in and the output embedding/bias are always kept in sync
    // on CPU (re-uploaded after SGD), so they do not need a readback.
    // ─────────────────────────────────────────────────────────────────────────

    pub fn save_weights(
        &self,
        header: &SovereignHeader,
        path:   &str,
    ) -> Result<(), SovereignError> {
        use encoder::{BPE_VOCAB_SIZE, D_BPE, D_MODEL, D_PHRASE, PHRASE_WIN_MIN};

        let num_l    = self.layers.len();
        let phrase_in = PHRASE_WIN_MIN * D_BPE;

        // ── Sync GPU → CPU for M matrices (checkpoint-only full readback) ──
        #[cfg(feature = "gpu")]
        {
            // Caller guarantees this is only called at checkpoint / end-of-training.
            // readback_all() blocks until GPU is idle, then copies M matrices to CPU.
            let readback = self.gpu.readback_all(num_l);
            // We need to write to self.memory_states, but `save_weights` takes &self.
            // Solution: temporarily coerce through a raw pointer (sound because the
            // GPU readback has already finished before we touch memory_states).
            //
            // SAFETY: No other thread accesses memory_states; the GPU is idle after
            // readback_all() returns; and we only write, never reallocate.
            let mem_states_mut = unsafe {
                &mut *((&self.memory_states) as *const Vec<Array2<f32>>
                    as *mut Vec<Array2<f32>>)
            };
            for (l, m_flat) in readback.m_states.iter().enumerate() {
                mem_states_mut[l] = Array2::from_shape_vec(
                    (RANK_R, RANK_R),
                    m_flat.clone(),
                ).expect("m_states reshape failed");
            }
        }

        // ── Flatten all parameters ────────────────────────────────────────
        let bpe_emb_flat:  Vec<f32> = self.encoder.bpe_embeddings.iter().cloned().collect();
        let w_fusion_flat: Vec<f32> = self.encoder.w_fusion.iter().cloned().collect();
        let w_phrase_flat: Vec<f32> = self.encoder.w_phrase.iter().cloned().collect();
        let w_in_flat:     Vec<f32> = self.reservoir.w_in.iter().cloned().collect();
        let w_lsh_flat:    Vec<f32> = self.lsh.w_lsh.iter().cloned().collect();
        let w_out_flat:    Vec<f32> = self.prediction_head.aggregator.w_out.iter().cloned().collect();
        let out_emb_flat:  Vec<f32> = self.prediction_head.head.output_embeddings.iter().cloned().collect();
        let out_bias_flat: Vec<f32> = self.prediction_head.head.output_bias.iter().cloned().collect();

        let mut layer_flats: Vec<(String, Vec<f32>, Vec<usize>)> = Vec::new();
        for (l, layer) in self.layers.iter().enumerate() {
            layer_flats.push((
                format!("w_down_{}", l),
                layer.w_down.iter().cloned().collect(),
                vec![RANK_R, D_MODEL],
            ));
            layer_flats.push((
                format!("w_up_{}", l),
                layer.w_up.iter().cloned().collect(),
                vec![RANK_R, N_RES],
            ));
            layer_flats.push((
                format!("m_base_{}", l),
                // NOTE: this is m_base (the resting-state attractor), NOT the
                // dynamic m_t state.  The dynamic state is serialised separately
                // if you want to resume from mid-training (uncomment the block below).
                layer.m_base.iter().cloned().collect(),
                vec![RANK_R, RANK_R],
            ));
            layer_flats.push((
                format!("gamma_{}", l),
                vec![layer.gamma],
                vec![1],
            ));
        }

        // ── Dynamic M state ───────────────────────────────────────────────
        // Optionally also persist the current m_t so that training can resume
        // without the fast Hebbian memory being cold-started.
        // Uncomment if your SovereignModel::load_from_file populates memory_states.
        //
        // for (l, m) in self.memory_states.iter().enumerate() {
        //     layer_flats.push((
        //         format!("m_state_{}", l),
        //         m.iter().cloned().collect(),
        //         vec![RANK_R, RANK_R],
        //     ));
        // }

        // ── Assemble entry list ───────────────────────────────────────────
        let mut entries: Vec<(&str, &[f32], &[usize])> = vec![
            ("bpe_embeddings",    &bpe_emb_flat,  &[BPE_VOCAB_SIZE, D_BPE]),
            ("w_fusion",          &w_fusion_flat, &[D_MODEL, D_MODEL]),
            ("w_phrase",          &w_phrase_flat, &[D_PHRASE, phrase_in]),
            ("w_in",              &w_in_flat,     &[N_RES, D_MODEL]),
            ("w_lsh",             &w_lsh_flat,    &[header.lsh_k, N_RES]),
            ("w_out",             &w_out_flat,    &[D_MODEL, N_RES]),
            ("output_embeddings", &out_emb_flat,  &[VOCAB_SIZE, D_MODEL]),
            ("output_bias",       &out_bias_flat, &[VOCAB_SIZE]),
        ];

        let layer_refs: Vec<(&str, &[f32], &[usize])> = layer_flats
            .iter()
            .map(|(n, d, s)| (n.as_str(), d.as_slice(), s.as_slice()))
            .collect();
        entries.extend_from_slice(&layer_refs);

        SovereignModel::save_to_file(header, &entries, path)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ForwardOutput
// ─────────────────────────────────────────────────────────────────────────────

pub struct ForwardOutput {
    pub logits:           Array1<f32>,
    pub sparse_logits:    Vec<memory::SparseLogit>,
    pub prediction_error: Array1<f32>,
    pub next_prediction:  Array1<f32>,
    pub kappas:           Vec<f32>,
    pub tension:          f32,
    pub beta_global:      f32,
}

// ─────────────────────────────────────────────────────────────────────────────
// SovereignModel random-LSM helper
// ─────────────────────────────────────────────────────────────────────────────

impl SovereignModel {
    pub fn new_random_lsm(header: &SovereignHeader) -> Array2<f32> {
        use rand::SeedableRng;
        use rand_distr::{Distribution, Normal};
        use rand_pcg::Pcg64;
        use rand::Rng;

        let n       = header.n_res;
        let density = header.lsm_density as f64;
        let std_dev = (1.0_f32 / n as f32).sqrt();
        let mut rng  = Pcg64::seed_from_u64(header.lsm_seed);
        let normal   = Normal::new(0.0_f32, std_dev).unwrap();

        let mut matrix = Array2::<f32>::zeros((n, n));
        for i in 0..n {
            for j in 0..n {
                if rng.gen_bool(density) {
                    matrix[[i, j]] = normal.sample(&mut rng);
                }
            }
        }
        matrix
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CLI
// ─────────────────────────────────────────────────────────────────────────────

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mode = args.get(1).map(String::as_str).unwrap_or("demo");

    match mode {
        "train" => run_train(
            args.get(2).map(String::as_str).unwrap_or("arca.sovereign"),
            args.get(3).map(String::as_str).unwrap_or("arca.tokenizer.json"),
        ),
        "infer" => run_infer(
            args.get(2).map(String::as_str).unwrap_or("arca.sovereign"),
            args.get(3).map(String::as_str).unwrap_or("arca.tokenizer.json"),
            args.get(4).map(String::as_str).unwrap_or("Hello ARCA"),
        ),
        "init" => run_init(
            args.get(2).map(String::as_str).unwrap_or("arca.sovereign"),
            args.get(3).map(String::as_str).unwrap_or("arca.tokenizer.json"),
        ),
        _ => run_demo(),
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Demo
// ─────────────────────────────────────────────────────────────────────────────

fn run_demo() {
    eprintln!("[ARCA] Smoke-test demo — random weights.");
    let header = SovereignHeader::default();
    let mut system = ArcaSystem::new_random(&header);

    let text = b"The adaptive resonant cortical architecture processes byte streams.";
    let tokenizer = BpeTokenizer::train(text, 32, 512);
    let bpe_ids   = tokenizer.encode_aligned(text);

    let mut prev_pred: Option<Array1<f32>> = None;
    let n_steps = text.len().min(15);
    let mut total_loss = 0.0_f32;

    for t in 0..n_steps {
        let output = system.forward_step(text, t, &bpe_ids, prev_pred.as_ref());
        let target = if t + 1 < text.len() { text[t + 1] as usize % VOCAB_SIZE } else { 0 };
        let losses = system.backward_step(&output, target);

        if t % 5 == 0 {
            eprintln!(
                "[step {:>3}] tension={:.4}  beta={:.4}  {}",
                t, output.tension, output.beta_global, losses
            );
        }
        total_loss += losses.total;
        prev_pred = Some(output.next_prediction);
    }

    eprintln!(
        "[ARCA] Done. Avg loss ({} steps): {:.4}",
        n_steps,
        total_loss / n_steps as f32
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// Init — create fresh .sovereign + tokenizer
// ─────────────────────────────────────────────────────────────────────────────

fn run_init(sovereign_path: &str, tokenizer_path: &str) {
    use rand::Rng;
    let header = SovereignHeader::default();
    let num_l  = header.num_layers;
    eprintln!("[ARCA] Initialising → {}", sovereign_path);

    let rand_vec = |r: usize, c: usize| -> Vec<f32> {
        let mut rng = rand::thread_rng();
        let scale    = (2.0 / (r + c) as f32).sqrt();
        (0..r * c).map(|_| rng.gen_range(-scale..scale)).collect()
    };
    let zero_vec = |n: usize| vec![0.0_f32; n];

    let phrase_in = PHRASE_WIN_MIN * D_BPE;

    let mut entries: Vec<(String, Vec<f32>, Vec<usize>)> = vec![
        ("bpe_embeddings".into(), rand_vec(BPE_VOCAB_SIZE, D_BPE), vec![BPE_VOCAB_SIZE, D_BPE]),
        ("w_fusion".into(),       rand_vec(D_MODEL, D_MODEL),       vec![D_MODEL, D_MODEL]),
        ("w_phrase".into(),       rand_vec(D_PHRASE, phrase_in),    vec![D_PHRASE, phrase_in]),
        ("w_in".into(),           rand_vec(N_RES, D_MODEL),         vec![N_RES, D_MODEL]),
        ("w_lsh".into(),          rand_vec(header.lsh_k, N_RES),    vec![header.lsh_k, N_RES]),
        ("w_out".into(),          rand_vec(D_MODEL, N_RES),         vec![D_MODEL, N_RES]),
        ("output_embeddings".into(), rand_vec(VOCAB_SIZE, D_MODEL), vec![VOCAB_SIZE, D_MODEL]),
        ("output_bias".into(),    zero_vec(VOCAB_SIZE),             vec![VOCAB_SIZE]),
    ];

    for l in 0..num_l {
        entries.push((format!("w_down_{}", l), rand_vec(RANK_R, D_MODEL), vec![RANK_R, D_MODEL]));
        entries.push((format!("w_up_{}", l),   rand_vec(RANK_R, N_RES),   vec![RANK_R, N_RES]));
        entries.push((format!("m_base_{}", l), zero_vec(RANK_R * RANK_R), vec![RANK_R, RANK_R]));
        let g: f32 = rand::thread_rng().gen_range(-0.05..0.05);
        entries.push((format!("gamma_{}", l),  vec![g],                   vec![1]));
    }

    let slices: Vec<(&str, &[f32], &[usize])> = entries
        .iter()
        .map(|(n, d, s)| (n.as_str(), d.as_slice(), s.as_slice()))
        .collect();

    SovereignModel::save_to_file(&header, &slices, sovereign_path)
        .expect("Failed to write .sovereign");

    let sz = std::fs::metadata(sovereign_path)
        .map(|m| m.len() as f64 / 1e6)
        .unwrap_or(0.0);
    eprintln!("[ARCA] Saved weights ({:.1} MB).", sz);

    let tokenizer = BpeTokenizer::new_base();
    tokenizer.save_to_json(tokenizer_path).expect("Failed to write tokenizer");
    eprintln!("[ARCA] Saved base tokenizer → {}", tokenizer_path);
}

// ─────────────────────────────────────────────────────────────────────────────
// Train
// ─────────────────────────────────────────────────────────────────────────────

fn run_train(sovereign_path: &str, tokenizer_path: &str) {
    let model = match SovereignModel::load_from_file(sovereign_path) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("[ARCA] {e}. Run `arca init {sovereign_path}` first.");
            return;
        }
    };
    let header = model.header.clone();
    let mut system = ArcaSystem::from_sovereign(&model).expect("build failed");
    eprintln!("[ARCA] Loaded. {} layers.", header.num_layers);

    let corpus: &[u8] =
        b"The model learns from raw byte streams without a fixed vocabulary. \
          Adaptive resonant cortical architecture combines liquid state machines \
          with bio-inspired holographic memory and homeostatic control. \
          Training proceeds online, one token at a time, updating both fast \
          Hebbian memory traces and slow skeleton parameters simultaneously.";

    let tokenizer = if std::path::Path::new(tokenizer_path).exists() {
        eprintln!("[ARCA] Loading tokenizer from {}", tokenizer_path);
        BpeTokenizer::load_from_json(tokenizer_path).expect("Failed to load tokenizer")
    } else {
        eprintln!("[ARCA] Training BPE tokenizer (256 merges)…");
        let tok = BpeTokenizer::train(corpus, 256, BPE_VOCAB_SIZE);
        tok.save_to_json(tokenizer_path).expect("Failed to save tokenizer");
        eprintln!("[ARCA] Tokenizer saved → {}", tokenizer_path);
        tok
    };

    let bpe_ids = tokenizer.encode_aligned(corpus);
    assert_eq!(bpe_ids.len(), corpus.len());

    const WINDOW: usize = 64;
    let batches = build_batches(corpus, &bpe_ids, WINDOW);
    eprintln!("[ARCA] {} batches of {} bytes.", batches.len(), WINDOW);

    system.reset_state();

    let ckpt_base       = sovereign_path.trim_end_matches(".sovereign");
    let mut global_step = 0usize;
    let mut total_loss  = 0.0_f32;

    for (batch_idx, batch) in batches.iter().enumerate() {
        let bytes = &batch.bytes;
        let ids   = &batch.bpe_ids;
        let mut prev_pred: Option<Array1<f32>> = None;

        for t in 0..bytes.len().saturating_sub(1) {
            let output     = system.forward_step(bytes, t, ids, prev_pred.as_ref());
            let target     = bytes[t + 1] as usize % VOCAB_SIZE;
            let losses     = system.backward_step(&output, target);

            if global_step % 20 == 0 {
                eprintln!("[batch {:>3} step {:>4}] {}", batch_idx, global_step, losses);
            }

            total_loss  += losses.total;
            global_step += 1;
            prev_pred    = Some(output.next_prediction);

            // After slow-learning SGD updates W_in / embeddings on CPU,
            // re-upload them to VRAM so the GPU stays in sync.
            // (Currently SGD only updates gamma; uncomment when you add
            //  skeleton weight updates for W_in / output_embeddings.)
            //
            // #[cfg(feature = "gpu")]
            // {
            //     let w_in_flat: Vec<f32> =
            //         system.reservoir.w_in.iter().cloned().collect();
            //     system.gpu.upload_w_in(&w_in_flat);
            //
            //     let emb_flat: Vec<f32> =
            //         system.prediction_head.head.output_embeddings.iter().cloned().collect();
            //     system.gpu.upload_output_embeddings(&emb_flat);
            // }

            // Checkpoint
            if system.train_state.should_checkpoint() {
                let ckpt_path =
                    format!("{}_step{}.sovereign", ckpt_base, system.train_state.step);
                match system.save_weights(&header, &ckpt_path) {
                    Ok(_)  => eprintln!("[ARCA] Checkpoint → {}", ckpt_path),
                    Err(e) => eprintln!("[ARCA] Checkpoint failed: {}", e),
                }
            }
        }

        system.reset_state();
    }

    eprintln!(
        "[ARCA] Training complete. {} steps, avg loss={:.4}",
        global_step,
        total_loss / global_step.max(1) as f32
    );

    match system.save_weights(&header, sovereign_path) {
        Ok(_) => {
            let sz = std::fs::metadata(sovereign_path)
                .map(|m| m.len() as f64 / 1e6)
                .unwrap_or(0.0);
            eprintln!("[ARCA] Saved → {} ({:.1} MB)", sovereign_path, sz);
        }
        Err(e) => eprintln!("[ARCA] Failed to save: {}", e),
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Infer
// ─────────────────────────────────────────────────────────────────────────────

fn run_infer(sovereign_path: &str, tokenizer_path: &str, prompt: &str) {
    let model = match SovereignModel::load_from_file(sovereign_path) {
        Ok(m)  => m,
        Err(e) => { eprintln!("[ARCA] {e}."); return; }
    };
    let mut system = ArcaSystem::from_sovereign(&model).expect("build failed");
    system.reset_state();

    let tokenizer = if std::path::Path::new(tokenizer_path).exists() {
        BpeTokenizer::load_from_json(tokenizer_path).expect("Failed to load tokenizer")
    } else {
        eprintln!("[ARCA] Tokenizer not found; falling back to byte-level.");
        BpeTokenizer::new_base()
    };

    let bytes   = prompt.as_bytes();
    let bpe_ids = tokenizer.encode_aligned(bytes);
    let mut prev_pred: Option<Array1<f32>> = None;

    for t in 0..bytes.len() {
        let output = system.forward_step(bytes, t, &bpe_ids, prev_pred.as_ref());
        prev_pred  = Some(output.next_prediction.clone());

        if t == bytes.len() - 1 {
            eprintln!("[ARCA] Top-5 predictions at position {}:", t);
            for (i, sl) in output.sparse_logits.iter().take(5).enumerate() {
                let ch = char::from_u32(sl.token_id).unwrap_or('?');
                eprintln!(
                    "  #{}: id={} ('{}') logit={:.4}",
                    i + 1, sl.token_id, ch, sl.logit
                );
            }
        }
    }
}
